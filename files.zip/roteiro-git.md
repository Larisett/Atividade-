# Roteiro de Git — BookShelf API

Siga a ordem das issues. Substitua `SEU-USUARIO` pelo seu usuário do GitHub.

## 0. Preparação (uma vez)

1. No GitHub, crie o repositório **`bookshelf-api`** (público, marcando "Add a README" para que `main` já tenha um commit inicial; assim você nunca precisa commitar direto em `main`).
2. Crie as issues: `./criar-issues.sh SEU-USUARIO/bookshelf-api`
3. Clone e crie a `develop`:

```bash
git clone https://github.com/SEU-USUARIO/bookshelf-api.git
cd bookshelf-api
git switch -c develop
git push -u origin develop
```

4. Copie os arquivos do pacote para dentro da pasta clonada, **mas não faça commit de tudo de uma vez**. Cada arquivo entra na branch da issue correspondente (tabela abaixo).

> **Dica:** deixe os arquivos em uma pasta temporária e vá copiando para o repositório a cada issue.

## 1. Ciclo de cada issue

```bash
git switch develop && git pull
git switch -c feature/issue-NN-descricao        # nome está na tabela
# ... copie/edite os arquivos da issue ...
git add <arquivos da issue>
git commit -m "feat(escopo): descrição curta (#NN)"   # 2 a 4 commits pequenos
git push -u origin feature/issue-NN-descricao
gh pr create --base develop --title "feat: ... (#NN)" --body "Closes #NN"
# revise o PR no GitHub, faça o merge (merge commit ou squash), depois:
git switch develop && git pull
git branch -d feature/issue-NN-descricao
```

Sem o `gh`, abra o PR pelo site do GitHub (o template já traz o campo `Closes #`).

## 2. Tabela de issues, branches e commits

| # | Branch | Arquivos | Commits sugeridos |
|---|--------|----------|-------------------|
| 1 | `feature/issue-01-setup-projeto` | `.gitignore`, `requirements*.txt`, `pytest.ini`, `LICENSE`, `.github/pull_request_template.md`, pastas vazias (`src/app/__init__.py`, `tests/__init__.py`) | `chore: adicionar .gitignore e licença (#1)` · `chore: adicionar dependências e configuração do pytest (#1)` · `chore: adicionar template de pull request (#1)` |
| 2 | `docs/issue-02-project-charter` | `docs/project-charter.md` | `docs(charter): definir visão e objetivos SMART (#2)` · `docs(charter): detalhar escopo e stakeholders (#2)` |
| 3 | `docs/issue-03-requisitos` | `docs/requisitos.md` | `docs(rf): listar requisitos funcionais (#3)` · `docs(rnf): detalhar requisitos não funcionais e regras de negócio (#3)` |
| 4 | `docs/issue-04-casos-de-uso` | `docs/casos-de-uso.md` | `docs(uc): descrever atores e UC01 a UC04 (#4)` · `docs(uc): descrever UC05 a UC07 (#4)` |
| 5 | `docs/issue-05-user-stories` | `docs/user-stories.md` | `docs(us): escrever histórias US01 a US05 (#5)` · `docs(us): escrever histórias US06 a US10 (#5)` |
| 6 | `docs/issue-06-readme-der` | `README.md`, `docs/der.md` | `docs(der): adicionar modelo de dados e arquitetura (#6)` · `docs(readme): escrever README completo (#6)` |
| 7 | `feature/issue-07-banco-modelos` | `src/app/database.py`, `models.py`, `schemas.py`, `main.py` | ver nota A |
| 8 | `feature/issue-08-crud-autores` | `src/app/routers/__init__.py`, `routers/authors.py` | ver nota B |
| 9 | `feature/issue-09-crud-livros` | `src/app/routers/books.py` | ver nota C |
| 10 | `feature/issue-10-bloqueio-exclusao-autor` | `routers/authors.py` (bloco da issue #10) | `feat(authors): bloquear exclusão de autor com livros (#10)` |
| 11 | `feature/issue-11-busca-paginacao` | `routers/books.py` (bloco da issue #11) | `feat(books): adicionar filtros de busca (#11)` · `feat(books): adicionar paginação (#11)` |
| 12 | `feature/issue-12-status-leitura` | `routers/books.py` (bloco da issue #12) | `feat(books): permitir alterar status de leitura (#12)` |
| 13 | `feature/issue-13-avaliacao` | `routers/books.py` (bloco da issue #13) | `feat(books): permitir avaliar livros lidos (#13)` |
| 14 | `feature/issue-14-estatisticas` | `routers/books.py` (bloco da issue #14) e `LibraryStats` em `schemas.py` | `feat(stats): adicionar resumo da biblioteca (#14)` |
| 15 | `feature/issue-15-testes` | `tests/*` | `test: adicionar fixtures (#15)` · `test(authors): cobrir CRUD e regras (#15)` · `test(books): cobrir livros, busca, status e estatísticas (#15)` |
| 16 | `feature/issue-16-ci` | `.github/workflows/ci.yml` | `ci: adicionar workflow de testes (#16)` |

### Como implementar o código em etapas (issues 7 a 14)
Os arquivos `authors.py` e `books.py` do pacote estão **completos**, com comentários `# --- Issue #N ... ---` / `# --- Fim Issue #N ---` marcando cada trecho. Para gerar um histórico incremental e honesto:

- **Nota A (issue 7):** em `main.py`, comente temporariamente as linhas `from .routers import authors, books` e os dois `include_router`. Em `schemas.py`, mantenha só `AuthorBase/Create/Out`, `BookBase/Create/Update/Out`, `BookPage`, `StatusUpdate`, `RatingUpdate`; deixe `LibraryStats` para a issue 14. Commits: `feat(db): configurar engine e sessão SQLite (#7)` · `feat(models): adicionar Author e Book (#7)` · `feat(schemas): adicionar schemas Pydantic (#7)` · `feat(api): criar app FastAPI com health check (#7)`.
- **Nota B (issue 8):** descomente `authors` em `main.py`. No `authors.py`, omita o `if author.books: raise ...` do `delete_author` (ele entra na issue 10). Commits: `feat(authors): cadastrar e listar autores (#8)` · `feat(authors): consultar e editar autor (#8)` · `feat(authors): excluir autor (#8)`.
- **Nota C (issue 9):** descomente `books` em `main.py`. Em `books.py`, comece só com os helpers, `create_book`, `get_book`, `update_book`, `delete_book` e um `list_books` simples (sem filtros, `limit`/`offset` fixos). Os blocos das issues 11 a 14 entram depois, um por branch.
- Escreva **testes junto com o código** se preferir (TDD); neste roteiro eles ficam na issue 15 para simplificar, mas nada impede de antecipar.

> Na issue 14, atenção: a rota `/books/stats` precisa ficar **antes** de `/books/{book_id}` no arquivo, senão o FastAPI tenta converter "stats" em inteiro e devolve 422.

## 3. Releases (SemVer) e fechamento das issues

Há uma pegadinha: o GitHub só **fecha issues automaticamente** quando o `Closes #N` chega à branch **padrão** (`main`). Como seus PRs vão para `develop`, as issues continuam abertas até a release. Por isso, ao final de cada marco, abra um PR **`develop` → `main`** listando todas as issues entregues:

```bash
gh pr create --base main --head develop \
  --title "release: v0.1.0" \
  --body "Closes #1, closes #2, closes #3, closes #4, closes #5, closes #6"
# faça o merge no GitHub, depois:
git switch main && git pull
git tag -a v0.1.0 -m "v0.1.0: fundação, documentação e README"
git push origin v0.1.0
git switch develop && git merge main && git push   # mantém develop sincronizada
```

> Em PRs, cada issue precisa da sua própria palavra-chave (`Closes #1, closes #2, ...`); `Closes #1, #2` fecharia só a primeira.

| Tag | Quando criar | Issues na release | Mensagem da tag |
|-----|--------------|-------------------|-----------------|
| `v0.1.0` | Após issues 1 a 6 | #1 a #6 | `v0.1.0: fundação, documentação e README` |
| `v0.2.0` | Após issues 7 a 10 | #7 a #10 | `v0.2.0: persistência e CRUD de autores e livros` |
| `v0.3.0` | Após issues 11 a 14 | #11 a #14 | `v0.3.0: busca, status, avaliação e estatísticas` |
| `v0.4.0` | Após issues 15 e 16 | #15 e #16 | `v0.4.0: testes automatizados e CI` |

Opcional: `gh release create v0.1.0 --title "v0.1.0" --generate-notes` para publicar a release na página do repositório.

## 4. Checklist final antes de enviar

- [ ] Nenhum commit direto em `main` (`git log --first-parent main` só mostra merges de `develop`)
- [ ] 16 issues criadas, com labels e critérios de aceite, todas fechadas
- [ ] 4 tags anotadas visíveis em *Releases/Tags*
- [ ] README com `SEU-USUARIO` substituído nos badges e no `git clone`, e nome em `LICENSE`
- [ ] Badge de build verde
- [ ] Link enviado é do repositório (`https://github.com/SEU-USUARIO/bookshelf-api`), não do perfil
