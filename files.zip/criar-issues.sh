#!/usr/bin/env bash
# Cria labels e as 16 issues do backlog via GitHub CLI (gh).
# Uso:  gh auth login   (uma vez)
#       ./criar-issues.sh SEU-USUARIO/bookshelf-api
# Rode em um repositório NOVO: a numeração (#1 a #16) segue a ordem abaixo.
# Sem o gh? Copie título, label e corpo de cada bloco e crie manualmente, na mesma ordem.
set -euo pipefail
REPO="${1:?uso: ./criar-issues.sh usuario/repositorio}"

for l in "documentation|0075ca" "feature|a2eeef" "enhancement|84b6eb" "chore|cfd3d7" "test|fbca04" "ci|5319e7"; do
  gh label create "${l%%|*}" --color "${l##*|}" --repo "$REPO" 2>/dev/null || true
done

new_issue() { gh issue create --repo "$REPO" --title "$1" --label "$2" --body "$3"; }

new_issue "chore: configurar estrutura inicial do projeto" "chore" "$(cat <<'EOF'
## Descrição
Criar a estrutura de pastas, `.gitignore`, `requirements*.txt`, `pytest.ini`, LICENSE e template de PR; criar a branch `develop`.

## Critérios de aceite
- [ ] Pastas `docs/`, `src/app/`, `tests/` existem
- [ ] `.gitignore` ignora `.venv/`, `__pycache__/` e `*.db`
- [ ] Branch `develop` criada a partir de `main`
- [ ] `pip install -r requirements-dev.txt` funciona

**Branch:** `feature/issue-01-setup-projeto`
EOF
)"

new_issue "docs: redigir Project Charter" "documentation" "$(cat <<'EOF'
## Descrição
Escrever `docs/project-charter.md` com justificativa, objetivos SMART, escopo (dentro/fora), stakeholders e marcos.

## Critérios de aceite
- [ ] Justificativa e visão geral presentes
- [ ] Ao menos 3 objetivos SMART mensuráveis
- [ ] Escopo lista o que está dentro e o que está fora
- [ ] Stakeholders e público-alvo identificados

**Branch:** `docs/issue-02-project-charter`
EOF
)"

new_issue "docs: especificar requisitos funcionais e não funcionais" "documentation" "$(cat <<'EOF'
## Descrição
Escrever `docs/requisitos.md` com RFs, RNFs e regras de negócio numerados e rastreáveis.

## Critérios de aceite
- [ ] RF01 a RF13 numerados, com prioridade
- [ ] RNFs cobrem desempenho, persistência, usabilidade, segurança e portabilidade
- [ ] Cada RF aponta para user story, caso de uso e issue

**Branch:** `docs/issue-03-requisitos`
EOF
)"

new_issue "docs: especificar casos de uso" "documentation" "$(cat <<'EOF'
## Descrição
Escrever `docs/casos-de-uso.md` com atores e fluxos das operações centrais.

## Critérios de aceite
- [ ] Atores descritos
- [ ] Cada caso de uso tem fluxo principal, alternativos e de exceção
- [ ] Casos de uso referenciam os RFs

**Branch:** `docs/issue-04-casos-de-uso`
EOF
)"

new_issue "docs: escrever user stories com critérios de aceite" "documentation" "$(cat <<'EOF'
## Descrição
Escrever `docs/user-stories.md` no padrão "Como... quero... para que..." com critérios em Gherkin.

## Critérios de aceite
- [ ] 10 histórias (US01 a US10) no padrão canônico
- [ ] Cada história tem ao menos 1 cenário Dado/Quando/Então
- [ ] Histórias cobrem todos os RFs

**Branch:** `docs/issue-05-user-stories`
EOF
)"

new_issue "docs: criar README detalhado e modelo de dados (DER)" "documentation" "$(cat <<'EOF'
## Descrição
Escrever o `README.md` completo e `docs/der.md` com DER e visão de arquitetura.

## Critérios de aceite
- [ ] README tem descrição do problema, badges, funcionalidades (feito vs planejado) e instruções de execução
- [ ] README linka todos os documentos de `docs/`
- [ ] README contém tabela/diagrama do fluxo de branches
- [ ] DER em Mermaid renderiza no GitHub

**Branch:** `docs/issue-06-readme-der`
EOF
)"

new_issue "feat: configurar banco de dados e modelos" "feature" "$(cat <<'EOF'
## Descrição
Implementar conexão SQLite com SQLAlchemy, modelos `Author` e `Book`, schemas Pydantic e `main.py` com `/health`.
Requisitos: RNF02, RN01, RN02, RN03, RN05.

## Critérios de aceite
```gherkin
Dado que a aplicação inicia
Quando o banco ainda não existe
Então as tabelas authors e books são criadas automaticamente

Quando eu envio GET /health
Então a resposta é 200 com {"status": "ok"}
```

**Branch:** `feature/issue-07-banco-modelos`
EOF
)"

new_issue "feat: implementar CRUD de autores" "feature" "$(cat <<'EOF'
## Descrição
Endpoints `POST/GET /authors` e `GET/PUT/DELETE /authors/{id}`. Cobre RF01, RF02, RF03 (US01, US02, US03).

## Critérios de aceite
```gherkin
Cenário: Cadastro com sucesso
  Quando eu envio POST /authors com name "Clarice Lispector"
  Então a resposta é 201 e contém um id

Cenário: Nome duplicado
  Dado que o autor "Clarice Lispector" já existe
  Quando eu envio POST /authors com o mesmo nome
  Então a resposta é 409

Cenário: Autor inexistente
  Quando eu envio GET /authors/999
  Então a resposta é 404
```

**Branch:** `feature/issue-08-crud-autores`
EOF
)"

new_issue "feat: implementar CRUD de livros" "feature" "$(cat <<'EOF'
## Descrição
Endpoints `POST/GET /books` e `GET/PUT/DELETE /books/{id}`. Cobre RF05 a RF09 (US04, US05, US06).

## Critérios de aceite
```gherkin
Cenário: Cadastro com sucesso
  Dado que o autor 1 existe
  Quando eu envio POST /books com title "Dom Casmurro" e author_id 1
  Então a resposta é 201 e o status é "quero_ler"

Cenário: Autor inexistente
  Quando eu envio POST /books com author_id 999
  Então a resposta é 404

Cenário: ISBN duplicado
  Quando eu cadastro um livro com ISBN já existente
  Então a resposta é 409

Cenário: Título vazio
  Quando eu envio POST /books com title ""
  Então a resposta é 422
```

**Branch:** `feature/issue-09-crud-livros`
EOF
)"

new_issue "feat: impedir exclusão de autor com livros vinculados" "feature" "$(cat <<'EOF'
## Descrição
Regra RN06 / RF04 (US03, UC06): `DELETE /authors/{id}` deve ser bloqueado se o autor tiver livros.

## Critérios de aceite
```gherkin
Cenário: Autor com livros
  Dado que o autor 1 tem ao menos um livro
  Quando eu envio DELETE /authors/1
  Então a resposta é 409 e o autor continua cadastrado

Cenário: Autor sem livros
  Dado que o autor 1 não tem livros
  Quando eu envio DELETE /authors/1
  Então a resposta é 204
```

**Branch:** `feature/issue-10-bloqueio-exclusao-autor`
EOF
)"

new_issue "feat: busca, filtros e paginação de livros" "feature" "$(cat <<'EOF'
## Descrição
Adicionar filtros `title`, `author`, `author_id`, `category`, `status` e paginação `limit`/`offset` em `GET /books`. Cobre RF06 e RF10 (US05, US07, UC03).

## Critérios de aceite
```gherkin
Cenário: Busca parcial por título
  Dado que existe o livro "Dom Casmurro"
  Quando eu envio GET /books?title=dom
  Então o resultado contém "Dom Casmurro"

Cenário: Paginação
  Dado 3 livros
  Quando eu envio GET /books?limit=2&offset=2
  Então a resposta tem 1 item e total 3

Cenário: Limite inválido
  Quando eu envio GET /books?limit=0
  Então a resposta é 422
```

**Branch:** `feature/issue-11-busca-paginacao`
EOF
)"

new_issue "feat: alterar status de leitura do livro" "feature" "$(cat <<'EOF'
## Descrição
Endpoint `PATCH /books/{id}/status`. Cobre RF11 (US08, UC04) e RN04 (nota removida ao sair de "lido").

## Critérios de aceite
```gherkin
Cenário: Alterar status
  Dado um livro "quero_ler"
  Quando eu envio PATCH /books/1/status com "lendo"
  Então a resposta é 200 e o status é "lendo"

Cenário: Status inválido
  Quando eu envio PATCH /books/1/status com "abc"
  Então a resposta é 422
```

**Branch:** `feature/issue-12-status-leitura`
EOF
)"

new_issue "feat: avaliar livros lidos com nota de 1 a 5" "feature" "$(cat <<'EOF'
## Descrição
Endpoint `PATCH /books/{id}/rating`. Cobre RF12 (US09, UC05) e RN04.

## Critérios de aceite
```gherkin
Cenário: Avaliar livro lido
  Dado um livro "lido"
  Quando eu envio PATCH /books/1/rating com 4
  Então a resposta é 200 e a nota é 4

Cenário: Livro não lido
  Dado um livro "lendo"
  Quando eu envio PATCH /books/1/rating com 4
  Então a resposta é 409

Cenário: Nota inválida
  Quando eu envio nota 6
  Então a resposta é 422
```

**Branch:** `feature/issue-13-avaliacao`
EOF
)"

new_issue "enhancement: endpoint de resumo estatístico da biblioteca" "enhancement" "$(cat <<'EOF'
## Descrição
Endpoint `GET /books/stats` com total de livros, contagem por status e média das notas. Cobre RF13 (US10, UC07).

## Critérios de aceite
```gherkin
Cenário: Resumo com dados
  Dado 2 livros, 1 "lido" com nota 4
  Quando eu envio GET /books/stats
  Então total_books é 2, by_status é {quero_ler: 1, lendo: 0, lido: 1} e average_rating é 4.0

Cenário: Biblioteca vazia
  Quando eu envio GET /books/stats
  Então total_books é 0 e average_rating é nulo
```

**Branch:** `feature/issue-14-estatisticas`
EOF
)"

new_issue "test: suíte de testes automatizados com cobertura mínima de 80%" "test" "$(cat <<'EOF'
## Descrição
Escrever testes pytest para autores, livros, busca, status/avaliação e estatísticas (RNF06).

## Critérios de aceite
- [ ] `pytest` passa localmente
- [ ] Cobertura ≥ 80% (`--cov-fail-under=80`)
- [ ] Cada regra de negócio (RN01 a RN06) tem ao menos um teste
- [ ] Casos de erro (404, 409, 422) cobertos

**Branch:** `feature/issue-15-testes`
EOF
)"

new_issue "ci: configurar GitHub Actions para rodar testes" "ci" "$(cat <<'EOF'
## Descrição
Workflow `.github/workflows/ci.yml` que instala dependências e roda `pytest` com cobertura em push e PR para `main` e `develop`.

## Critérios de aceite
- [ ] Workflow executa em PRs e pushes
- [ ] Falha se a cobertura ficar abaixo de 80%
- [ ] Badge de build no README aponta para o workflow

**Branch:** `feature/issue-16-ci`
EOF
)"

echo "Pronto: 16 issues criadas em $REPO"
